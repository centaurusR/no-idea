<?php
class Hamkar_Plus_Extensions {
    private static $instance;
    private $extensions = [];

    public static function init() {
        if (is_null(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->load_extensions();
        add_action('admin_init', [$this, 'manage_extensions']);
    }

    public function load_extensions() {
        $extensions_dir = HAMKAR_PATH . 'extensions/';
        if (!is_dir($extensions_dir)) {
            return;
        }

        $active_extensions = get_option('hamkar_active_extensions', []);
        foreach (glob($extensions_dir . '*', GLOB_ONLYDIR) as $dir) {
            $slug = basename($dir);
            $file = $dir . '/' . $slug . '.php';
            if (file_exists($file)) {
                $this->extensions[$slug] = [
                    'name' => $slug,
                    'path' => $file,
                    'active' => in_array($slug, $active_extensions)
                ];
                if (in_array($slug, $active_extensions)) {
                    include_once $file;
                    $css_file = $dir . '/assets/style.css';
                    if (file_exists($css_file)) {
                        add_action('admin_enqueue_scripts', function() use ($css_file, $slug) {
                            wp_enqueue_style('ext-' . $slug, plugins_url('extensions/' . $slug . '/assets/style.css', HAMKAR_PATH), ['shared-style'], '1.0');
                        });
                    }
                }
            }
        }

        // نمایش محتوای HireWire
        if (isset($this->extensions['hirewire']) && $this->extensions['hirewire']['active']) {
            add_action('hamkar_extension_page_hirewire', function() {
                ?>
                <div class="shared-card">
                    <h2 class="shared-title">رزومه‌ها</h2>
                    <div class="shared-resume">
                        <img src="https://via.placeholder.com/40" alt="Jacob Jones">
                        <div class="shared-resume-details">
                            <span class="shared-resume-name">Jacob Jones</span>
                            <span class="shared-resume-title">Marketing Manager</span>
                        </div>
                    </div>
                    <div class="shared-resume">
                        <img src="https://via.placeholder.com/40" alt="Kristin Watson">
                        <div class="shared-resume-details">
                            <span class="shared-resume-name">Kristin Watson</span>
                            <span class="shared-resume-title">UI Designer</span>
                        </div>
                    </div>
                    <div class="shared-resume">
                        <img src="https://via.placeholder.com/40" alt="Darlene Robertson">
                        <div class="shared-resume-details">
                            <span class="shared-resume-name">Darlene Robertson</span>
                            <span class="shared-resume-title">Designer</span>
                        </div>
                    </div>
                    <div style="display: flex; gap: 0.5rem; margin-top: 1rem;">
                        <button class="shared-btn">Archive</button>
                        <button class="shared-btn">PDF</button>
                        <button class="shared-btn">View All</button>
                    </div>
                </div>
                <?php
            });
        }
    }

    public function manage_extensions() {
        if (!current_user_can('manage_options')) {
            return;
        }

        if (isset($_POST['hamkar_activate_extension']) && check_admin_referer('hamkar_manage_extensions')) {
            $slug = sanitize_text_field($_POST['extension_slug']);
            if (isset($this->extensions[$slug])) {
                $active_extensions = get_option('hamkar_active_extensions', []);
                if (!in_array($slug, $active_extensions)) {
                    $active_extensions[] = $slug;
                    update_option('hamkar_active_extensions', $active_extensions);
                    wp_redirect(admin_url('admin.php?page=hamkar_extensions&message=activated'));
                    exit;
                }
            }
        }

        if (isset($_POST['hamkar_deactivate_extension']) && check_admin_referer('hamkar_manage_extensions')) {
            $slug = sanitize_text_field($_POST['extension_slug']);
            if (isset($this->extensions[$slug])) {
                $active_extensions = get_option('hamkar_active_extensions', []);
                if (($key = array_search($slug, $active_extensions)) !== false) {
                    unset($active_extensions[$key]);
                    update_option('hamkar_active_extensions', array_values($active_extensions));
                    wp_redirect(admin_url('admin.php?page=hamkar_extensions&message=deactivated'));
                    exit;
                }
            }
        }
    }

    public function get_extensions() {
        return $this->extensions;
    }

    public function get_available_extensions() {
        $extensions_dir = HAMKAR_PATH . 'extensions/';
        $extensions_list = [];
        if (!is_dir($extensions_dir)) {
            return $extensions_list;
        }

        foreach (glob($extensions_dir . '*', GLOB_ONLYDIR) as $dir) {
            $slug = basename($dir);
            $file = $dir . '/' . $slug . '.php';
            if (file_exists($file)) {
                $extensions_list[] = [
                    'name' => $slug,
                    'slug' => $slug,
                    'description' => 'اکستنشن ' . $slug,
                    'active' => isset($this->extensions[$slug]) && $this->extensions[$slug]['active']
                ];
            }
        }
        return $extensions_list;
    }
}