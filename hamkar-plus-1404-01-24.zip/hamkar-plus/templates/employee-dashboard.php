<?php
if (!is_user_logged_in()) {
    wp_redirect(wp_login_url(admin_url('admin.php?page=hamkar_plus')));
    exit;
}

$current_user = wp_get_current_user();
if (!current_user_can('hamkar_collaborator') && !current_user_can('manage_options')) {
    wp_die('شما دسترسی لازم برای مشاهده این صفحه را ندارید.');
}

$avatar = get_avatar_url($current_user->ID, ['size' => 100]);
$active_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'dashboard';
$extensions_manager = Hamkar_Plus_Extensions::init();
$active_extensions = $extensions_manager->get_available_extensions();
?>

<div class="shared-container">
    <div class="shared-card">
        <div class="hamkar-profile-header">
            <div class="hamkar-profile-info">
                <img src="<?php echo esc_url($avatar); ?>" alt="پروفایل" class="shared-avatar">
                <div class="hamkar-profile-details">
                    <h2 class="shared-title">خوش آمدید، <?php echo esc_html($current_user->display_name); ?>!</h2>
                    <p>ایمیل: <?php echo esc_html($current_user->user_email); ?></p>
                    <p>کد پرسنلی: <?php echo esc_html(get_user_meta($current_user->ID, 'teamfolio_personnel_code', true)); ?></p>
                </div>
            </div>
            <a href="<?php echo wp_logout_url(home_url()); ?>" class="shared-btn">خروج</a>
        </div>
    </div>

    <div class="shared-card">
        <ul class="shared-list">
            <li class="shared-list-item <?php echo $active_tab === 'dashboard' ? 'active' : ''; ?>">
                <a href="<?php echo admin_url('admin.php?page=hamkar_plus&tab=dashboard'); ?>">میز کار</a>
            </li>
            <?php foreach ($active_extensions as $ext) : if ($ext['active']) : ?>
                <li class="shared-list-item <?php echo $active_tab === $ext['slug'] ? 'active' : ''; ?>">
                    <a href="<?php echo admin_url("admin.php?page=hamkar_plus&tab={$ext['slug']}"); ?>">
                        <?php echo ($ext['slug'] === 'hirewire') ? 'رزومه‌ها' : esc_html($ext['name']); ?>
                    </a>
                </li>
            <?php endif; endforeach; ?>
        </ul>
    </div>

    <div class="shared-card">
        <?php if ($active_tab === 'dashboard') : ?>
            <h2 class="shared-title">منابع انسانی</h2>
            <div class="hamkar-dashboard-box">
                <div style="display: flex; gap: 1rem;">
                    <div style="flex: 1;">
                        <h3 class="shared-title">کارکنان</h3>
                        <div class="shared-circle-chart">
                            <span>135</span>
                        </div>
                        <h3 class="shared-title">استخدام‌های جدید</h3>
                        <div class="shared-circle-chart">
                            <span>8</span>
                        </div>
                    </div>
                    <div style="flex: 1;">
                        <h3 class="shared-title">درصد</h3>
                        <div class="shared-circle-chart">
                            <span>74%</span>
                        </div>
                        <div class="shared-bar-chart">
                            <div class="shared-bar" style="height: 30%;"></div>
                            <div class="shared-bar" style="height: 70%;"></div>
                            <div class="shared-bar" style="height: 50%;"></div>
                        </div>
                    </div>
                </div>
                <div class="shared-line-chart">
                    <div class="shared-line"></div>
                </div>
            </div>
        <?php else : ?>
            <?php do_action('hamkar_employee_dashboard_content_' . $active_tab); ?>
        <?php endif; ?>
    </div>
</div>