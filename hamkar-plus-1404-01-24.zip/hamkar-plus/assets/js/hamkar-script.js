jQuery(document).ready(function($) {
    // انیمیشن ساده برای دکمه‌ها
    $('.btn-glass').on('click', function() {
        $(this).addClass('clicked');
        setTimeout(() => $(this).removeClass('clicked'), 300);
    });

    // نمایش/پنهان‌سازی یک المان
    window.toggleElement = function(id) {
        const el = document.getElementById(id);
        if (!el) return;
        el.style.display = el.style.display === 'none' ? 'block' : 'none';
    };
});