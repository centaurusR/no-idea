jQuery(document).ready(function($) {
    $('.shared-btn').on('click', function() {
        $(this).addClass('clicked');
        setTimeout(() => $(this).removeClass('clicked'), 300);
    });

    window.sharedToggle = function(id) {
        const el = document.getElementById(id);
        if (el) {
            el.style.display = el.style.display === 'none' ? 'block' : 'none';
        }
    };
});