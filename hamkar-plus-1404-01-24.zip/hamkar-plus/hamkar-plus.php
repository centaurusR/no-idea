<?php
/*
Plugin Name: Hamkar Plus
Description: پلاگین مدیریت تیم و همکاری سازمانی
Version: 1.0
Author: تصویر سنتورس
Author URI: https://centauruspicture.ir/
License: GPL-2.0+
*/

if (!defined('ABSPATH')) {
    exit;
}

define('HAMKAR_PATH', plugin_dir_path(__FILE__));
define('HAMKAR_URL', plugin_dir_url(__FILE__));

require_once HAMKAR_PATH . 'core/class-extensions.php';

add_action('init', 'hamkar_load_extensions_on_init', 1);
function hamkar_load_extensions_on_init() {
    $extensions_manager = Hamkar_Plus_Extensions::init();
    $extensions_manager->load_extensions();
}

add_action('init', 'hamkar_register_roles');
function hamkar_register_roles() {
    add_role('hamkar_collaborator', 'کارمند همکار', ['read' => true]);
}

register_activation_hook(__FILE__, 'hamkar_auto_activate_extensions');
function hamkar_auto_activate_extensions() {
    $extensions_manager = Hamkar_Plus_Extensions::init();
    $available_extensions = $extensions_manager->get_available_extensions();
    $active_extensions = get_option('hamkar_active_extensions', []);
    foreach ($available_extensions as $ext) {
        if (!in_array($ext['slug'], $active_extensions)) {
            $active_extensions[] = $ext['slug'];
        }
    }
    update_option('hamkar_active_extensions', $active_extensions);
}

register_activation_hook(__FILE__, 'hamkar_cleanup_login_options');
function hamkar_cleanup_login_options() {
    delete_option('hamkar_atlas_page_created');
    delete_option('hamkar_login_background');
}

add_action('admin_menu', 'hamkar_register_menu', 999);
function hamkar_register_menu() {
    global $submenu;

    add_menu_page(
        'همکار پلاس',
        'همکار پلاس',
        'read',
        'hamkar_plus',
        'hamkar_dashboard_page',
        'dashicons-groups',
        3
    );
    add_submenu_page(
        'hamkar_plus',
        'داشبورد',
        'داشبورد',
        'read',
        'hamkar_plus',
        'hamkar_dashboard_page'
    );
    add_submenu_page(
        'hamkar_plus',
        'اکستنشن‌ها',
        'اکستنشن‌ها',
        'manage_options',
        'hamkar_extensions',
        'hamkar_extensions_page'
    );
    add_submenu_page(
        'hamkar_plus',
        'تنظیمات همکار پلاس',
        'تنظیمات',
        'manage_options',
        'hamkar_settings',
        'hamkar_settings_page'
    );

    $extensions_manager = Hamkar_Plus_Extensions::init();
    $extensions = $extensions_manager->get_available_extensions();
    foreach ($extensions as $ext) {
        if ($ext['active']) {
            // تغییر نام HireWire به رزومه‌ها
            $menu_title = ($ext['slug'] === 'hirewire') ? 'رزومه‌ها' : $ext['name'];
            add_submenu_page(
                'hamkar_plus',
                $menu_title,
                $menu_title,
                'manage_options',
                'hamkar_extension_' . $ext['slug'],
                function() use ($ext) {
                    echo '<div class="shared-container">';
                    do_action('hamkar_extension_page_' . $ext['slug']);
                    echo '</div>';
                }
            );
        }
    }

    // حذف منوهای اضافی اکستنشن‌ها (مثل منوی جداگونه رزومه‌ها)
    foreach ($submenu as $parent => $items) {
        if ($parent !== 'hamkar_plus') {
            foreach ($items as $key => $item) {
                if (isset($item[2]) && (strpos($item[2], 'hamkar_extension_') !== false || $item[2] === 'hirewire' || $item[0] === 'رزومه‌ها')) {
                    unset($submenu[$parent][$key]);
                }
            }
        }
    }
}

add_action('admin_init', 'hamkar_register_settings');
function hamkar_register_settings() {
    register_setting('hamkar_settings_group', 'hamkar_date_format');
    register_setting('hamkar_settings_group', 'hamkar_language');
}

add_action('init', 'hamkar_register_log_post_type');
function hamkar_register_log_post_type() {
    register_post_type('hamkar_log', array(
        'labels' => array(
            'name' => 'لاگ‌ها',
            'singular_name' => 'لاگ',
        ),
        'public' => false,
        'show_ui' => true,
        'show_in_menu' => 'hamkar_plus',
        'supports' => array('title', 'editor'),
        'capability_type' => 'post',
        'capabilities' => array('create_posts' => 'do_not_allow'),
        'map_meta_cap' => true,
    ));
}

function hamkar_log_activity($action, $details) {
    $user = wp_get_current_user();
    $log_data = array(
        'post_title' => sprintf('فعالیت: %s توسط %s', $action, $user->display_name),
        'post_content' => $details,
        'post_type' => 'hamkar_log',
        'post_status' => 'private',
        'post_author' => $user->ID,
    );
    wp_insert_post($log_data);
}

function hamkar_dashboard_page() {
    if (!is_user_logged_in()) {
        wp_redirect(wp_login_url(admin_url('admin.php?page=hamkar_plus')));
        exit;
    }
    if (!current_user_can('hamkar_collaborator') && !current_user_can('manage_options')) {
        wp_die('شما دسترسی لازم برای مشاهده این صفحه را ندارید.');
    }
    include HAMKAR_PATH . 'templates/employee-dashboard.php';
}

function hamkar_extensions_page() {
    $api_url = 'https://centauruspicture.ir/wp-json/centaurus/v1/extensions';
    $response = wp_remote_get($api_url, array('timeout' => 15, 'sslverify' => false));
    $extensions_list = [];
    if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
        $extensions_list = json_decode(wp_remote_retrieve_body($response), true);
    }

    if (isset($_POST['install_extension_from_url']) && check_admin_referer('hamkar_install_extension_from_url')) {
        $extension_url = esc_url_raw($_POST['extension_url']);
        $extension_slug = sanitize_text_field($_POST['extension_slug']);
        if (empty($extension_url) || empty($extension_slug)) {
            echo '<div class="error"><p>لطفاً لینک و نام اکستنشن را وارد کنید.</p></div>';
        } else {
            $temp_file = download_url($extension_url);
            if (!is_wp_error($temp_file)) {
                $extension_dir = HAMKAR_PATH . 'extensions/' . $extension_slug;
                if (!file_exists($extension_dir)) {
                    mkdir($extension_dir, 0755, true);
                }
                $zip = new ZipArchive();
                if ($zip->open($temp_file) === true) {
                    $zip->extractTo($extension_dir);
                    $zip->close();
                    echo '<div class="updated"><p>اکستنشن با موفقیت نصب شد!</p></div>';
                } else {
                    echo '<div class="error"><p>خطا در نصب اکستنشن!</p></div>';
                }
                unlink($temp_file);
            } else {
                echo '<div class="error"><p>خطا در دانلود: ' . esc_html($temp_file->get_error_message()) . '</p></div>';
            }
        }
    }

    $extensions_manager = Hamkar_Plus_Extensions::init();
    $installed_extensions = $extensions_manager->get_available_extensions();
    ?>
    <div class="shared-container">
        <div class="shared-card">
            <h1 class="shared-title">اکستنشن‌ها</h1>
            <?php if (isset($_GET['message'])) : ?>
                <div class="updated">
                    <p><?php echo $_GET['message'] === 'activated' ? 'اکستنشن فعال شد!' : 'اکستنشن غیرفعال شد!'; ?></p>
                </div>
            <?php endif; ?>
            <h2 class="shared-title">اکستنشن‌های موجود</h2>
            <?php if (!empty($extensions_list)) : ?>
                <table class="shared-table">
                    <thead>
                        <tr>
                            <th>نام</th>
                            <th>توضیحات</th>
                            <th>عملیات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($extensions_list as $ext) : ?>
                            <tr>
                                <td><?php echo esc_html($ext['name']); ?></td>
                                <td><?php echo esc_html($ext['description']); ?></td>
                                <td>
                                    <form method="post" style="display:inline;">
                                        <?php wp_nonce_field('hamkar_install_extension_from_url'); ?>
                                        <input type="hidden" name="extension_slug" value="<?php echo esc_attr($ext['slug']); ?>">
                                        <input type="hidden" name="extension_url" value="<?php echo esc_url($ext['download_url']); ?>">
                                        <button type="submit" name="install_extension_from_url" class="shared-btn">نصب</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else : ?>
                <p>هیچ اکستنشن‌ای یافت نشد.</p>
            <?php endif; ?>

            <h2 class="shared-title">اکستنشن‌های نصب‌شده</h2>
            <?php if (!empty($installed_extensions)) : ?>
                <table class="shared-table">
                    <thead>
                        <tr>
                            <th>نام</th>
                            <th>توضیحات</th>
                            <th>وضعیت</th>
                            <th>عملیات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($installed_extensions as $ext) : ?>
                            <tr>
                                <td><?php echo esc_html($ext['name']); ?></td>
                                <td><?php echo esc_html($ext['description']); ?></td>
                                <td><?php echo $ext['active'] ? 'فعال' : 'غیرفعال'; ?></td>
                                <td>
                                    <?php if (!$ext['active']) : ?>
                                        <form method="post" style="display:inline;">
                                            <?php wp_nonce_field('hamkar_manage_extensions'); ?>
                                            <input type="hidden" name="extension_slug" value="<?php echo esc_attr($ext['slug']); ?>">
                                            <button type="submit" name="hamkar_activate_extension" class="shared-btn">فعال‌سازی</button>
                                        </form>
                                    <?php else : ?>
                                        <form method="post" style="display:inline;">
                                            <?php wp_nonce_field('hamkar_manage_extensions'); ?>
                                            <input type="hidden" name="extension_slug" value="<?php echo esc_attr($ext['slug']); ?>">
                                            <button type="submit" name="hamkar_deactivate_extension" class="shared-btn">غیرفعال‌سازی</button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else : ?>
                <p>هیچ اکستنشن‌ای نصب نشده است.</p>
            <?php endif; ?>
        </div>
    </div>
    <?php
}

function hamkar_settings_page() {
    $languages = [
        'fa' => 'فارسی',
        'en' => 'انگلیسی',
        'ar' => 'عربی',
    ];
    ?>
    <div class="shared-container">
        <div class="shared-card">
            <h1 class="shared-title">تنظیمات همکار پلاس</h1>
            <form method="post" action="options.php">
                <?php settings_fields('hamkar_settings_group'); ?>
                <div class="shared-form-field">
                    <label for="hamkar_date_format">فرمت تاریخ</label>
                    <select name="hamkar_date_format" id="hamkar_date_format">
                        <option value="jalali" <?php selected(get_option('hamkar_date_format', 'jalali'), 'jalali'); ?>>شمسی</option>
                        <option value="gregorian" <?php selected(get_option('hamkar_date_format'), 'gregorian'); ?>>میلادی</option>
                    </select>
                </div>
                <div class="shared-form-field">
                    <label for="hamkar_language">زبان سیستم</label>
                    <select name="hamkar_language" id="hamkar_language">
                        <?php foreach ($languages as $code => $name) : ?>
                            <option value="<?php echo esc_attr($code); ?>" <?php selected(get_option('hamkar_language', 'fa'), $code); ?>><?php echo esc_html($name); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <?php submit_button('ذخیره تنظیمات', 'shared-btn', 'submit', false); ?>
                </div>
            </form>
        </div>
    </div>
    <?php
}

add_action('admin_enqueue_scripts', 'hamkar_enqueue_assets');
function hamkar_enqueue_assets($hook) {
    // فقط برای صفحات همکار پلاس استایل رو لود کن
    if (strpos($hook, 'hamkar_') !== false) {
        wp_enqueue_style('shared-style', HAMKAR_URL . 'assets/css/shared-style.css', [], '1.1');
        wp_enqueue_script('shared-script', HAMKAR_URL . 'assets/js/shared-script.js', ['jquery'], '1.1', true);
    }
}