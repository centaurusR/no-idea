jQuery(document).ready(function($) {
    $('.upload-signature, .upload-logo').click(function(e) {
        e.preventDefault();
        const uploader = wp.media({
            title: 'آپلود فایل',
            button: { text: 'انتخاب فایل' },
            multiple: false
        }).on('select', function() {
            const attachment = uploader.state().get('selection').first().toJSON();
            $('#signature_url, #logo_url').val(attachment.url);
        }).open();
    });
});