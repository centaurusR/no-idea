jQuery(document).ready(function($) {
    // پرینت
    $('.print-letter').click(function() {
        const letterId = $(this).data('letter-id');
        const url = window.location.origin + window.location.pathname + '?letter=' + letterId + '&action=print';
        window.open(url, '_blank');
    });

    // مشاهده
    $('.view-letter').click(function() {
        const letterId = $(this).data('letter-id');
        const url = window.location.origin + window.location.pathname + '?letter=' + letterId + '&action=view';
        window.open(url, '_blank');
    });

    // دانلود تصویر
    $('.download-image').click(function() {
        const letterId = $(this).data('letter-id');
        $.post(letter_vars.ajaxurl, {
            action: 'letter_generate_image',
            letter_id: letterId,
            _nonce: letter_vars.nonce
        }, function(response) {
            if (response.success) {
                window.location.href = response.data.url;
            } else {
                alert('خطا در تولید تصویر: ' + response.data.message);
            }
        }).fail(function() {
            alert('خطا در تولید تصویر. لطفاً مطمئن شوید که wkhtmltoimage روی سرور نصب شده است.');
        });
    });

    // نمایش گزینه‌های ارسال
    $('.send-options').click(function() {
        $(this).siblings('.send-options-box').toggle();
    });

    // تغییر روش ارسال
    $('.send-method').change(function() {
        const method = $(this).val();
        $(this).siblings('.users-box, .email-box').hide();
        if (method === 'users') {
            $(this).siblings('.users-box').show();
        } else if (method === 'email') {
            $(this).siblings('.email-box').show();
        }
    });

    // ارسال
    $('.send-letter').click(function() {
        const method = $(this).siblings('.send-method').val();
        const letterId = $(this).data('letter-id');

        if (method === 'print') {
            const url = window.location.origin + window.location.pathname + '?letter=' + letterId + '&action=print';
            window.open(url, '_blank');
        } else if (method === 'users') {
            const role = $(this).siblings('.users-box').find('.user-roles').val();
            $.post(letter_vars.ajaxurl, {
                action: 'letter_send_to_users',
                letter_id: letterId,
                role: role,
                _nonce: letter_vars.nonce
            }, function(response) {
                alert(response.data.message);
            });
        } else if (method === 'email') {
            const email = $(this).siblings('.email-box').find('.email-input').val();
            $.post(letter_vars.ajaxurl, {
                action: 'letter_send_email',
                letter_id: letterId,
                email: email,
                _nonce: letter_vars.nonce
            }, function(response) {
                alert(response.data.message);
            });
        }
    });
});