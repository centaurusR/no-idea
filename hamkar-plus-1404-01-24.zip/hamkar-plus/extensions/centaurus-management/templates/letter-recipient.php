<div class="letter-output">
    <table>
        <tr>
            <td>
                <img src="<?php echo get_option('letter_logo_url', ''); ?>" alt="Logo" class="logo">
            </td>
            <td><?php echo esc_html($letter->letter_number); ?></td>
            <td><?php echo get_current_persian_date(); ?></td>
        </tr>
        <tr>
            <td><?php echo esc_html($letter->recipient_name); ?></td>
            <td><?php echo esc_html($letter->recipient_position); ?></td>
            <td><?php echo esc_html($letter->subject); ?></td>
        </tr>
        <tr>
            <td colspan="3" class="content">
                <p>با سلام و احترام</p>
                <?php echo wpautop($letter->content); ?>
            </td>
        </tr>
        <tr>
            <td><?php echo esc_html($letter->sender_name); ?></td>
            <td><?php echo esc_html($letter->sender_position); ?></td>
            <td class="signature">
                <?php if ($letter->signature_url) : ?>
                    <img src="<?php echo esc_url($letter->signature_url); ?>" alt="Signature">
                <?php endif; ?>
            </td>
        </tr>
    </table>
</div>