<?php
/*
Plugin Name: Centaurus Management
Description: سیستم کامل مدیریت نامه‌های اداری
Version: 3.6
Author: Grok
*/

defined('ABSPATH') || exit;

// ثابت‌ها
define('LETTER_PATH', plugin_dir_path(__FILE__));
define('LETTER_URL', plugin_dir_url(__FILE__));

// فعال‌سازی: ایجاد جداول دیتابیس
register_activation_hook(__FILE__, 'letter_create_tables');
function letter_create_tables() {
    global $wpdb;
    $charset = $wpdb->get_charset_collate();

    $letters_table = $wpdb->prefix . 'letters';
    $sql = "CREATE TABLE $letters_table (
        id INT NOT NULL AUTO_INCREMENT,
        letter_number VARCHAR(20),
        subject TEXT,
        content LONGTEXT,
        recipient_name TEXT,
        recipient_position TEXT,
        sender_name TEXT,
        sender_position TEXT,
        signature_url VARCHAR(255),
        document_type VARCHAR(10),
        document_class VARCHAR(10),
        document_subject VARCHAR(10),
        status VARCHAR(20) DEFAULT 'draft',
        archived TINYINT(1) DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $charset;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

// حذف پلاگین
register_uninstall_hook(__FILE__, 'letter_uninstall');
function letter_uninstall() {
    global $wpdb;
    $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}letters");
}

// افزودن منوی مدیریت (به عنوان منوی اصلی توی داشبورد)
add_action('admin_menu', 'letter_admin_menu');
function letter_admin_menu() {
    // منوی اصلی
    add_menu_page(
        'مدیریت نامه‌ها',
        'مدیریت نامه‌ها',
        'manage_options',
        'letter-management',
        'letter_issue_page',
        'dashicons-email-alt'
    );

    // زیرمنوی "بایگانی"
    add_submenu_page(
        'letter-management',
        'بایگانی',
        'بایگانی',
        'manage_options',
        'letter-archive',
        'letter_archive_page'
    );

    // زیرمنوی "تنظیمات"
    add_submenu_page(
        'letter-management',
        'تنظیمات',
        'تنظیمات',
        'manage_options',
        'letter-settings',
        'letter_render_settings_page'
    );
}

// صفحه تنظیمات
function letter_render_settings_page() {
    if (isset($_POST['submit_settings']) && check_admin_referer('letter_save_settings')) {
        update_option('letter_logo_url', esc_url_raw($_POST['logo_url']));
        update_option('letter_footer_text', wp_kses_post($_POST['footer_text']));
    }
    $logo_url = get_option('letter_logo_url', '');
    $footer_text = get_option('letter_footer_text', '');
    ?>
    <div class="wrap letter-wrap">
        <h1>تنظیمات</h1>
        <div class="letter-content">
            <form method="post">
                <?php wp_nonce_field('letter_save_settings'); ?>
                <div class="form-field">
                    <label for="logo_url">آپلود لوگو</label>
                    <input type="hidden" name="logo_url" id="logo_url" value="<?php echo esc_url($logo_url); ?>">
                    <button type="button" class="upload-logo button">آپلود لوگو</button>
                    <?php if ($logo_url) : ?>
                        <img src="<?php echo esc_url($logo_url); ?>" style="max-width: 100px; display: block; margin-top: 10px;">
                    <?php endif; ?>
                </div>
                <div class="form-field">
                    <label for="footer_text">متن پاورقی ایمیل</label>
                    <textarea name="footer_text" id="footer_text" rows="5" style="width: 100%;"><?php echo esc_textarea($footer_text); ?></textarea>
                    <p class="description">این متن در پاورقی ایمیل‌های ارسالی نمایش داده می‌شود.</p>
                </div>
                <button type="submit" name="submit_settings" class="letter-button">ذخیره</button>
            </form>
        </div>
    </div>
    <?php
}

// بارگذاری اسکریپت‌ها و استایل‌ها
add_action('admin_enqueue_scripts', 'letter_enqueue_admin_assets');
function letter_enqueue_admin_assets($hook) {
    $allowed_hooks = [
        'toplevel_page_letter-management',
        'letter-management_page_letter-archive',
        'letter-management_page_letter-settings'
    ];

    if (!in_array($hook, $allowed_hooks)) {
        return;
    }

    wp_enqueue_style('letter-style', LETTER_URL . 'assets/css/letter-style.css', [], '3.6');
    wp_enqueue_script('letter-print', LETTER_URL . 'assets/js/print.js', ['jquery'], '3.6', true);
    wp_enqueue_script('letter-upload-signature', LETTER_URL . 'assets/js/upload-signature.js', ['jquery'], '3.6', true);
    wp_enqueue_media();

    wp_localize_script('letter-print', 'letter_vars', [
        'ajaxurl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('letter_send_email')
    ]);
}

// لود استایل‌ها توی فرانت‌اند (برای شورت‌کد)
add_action('wp_enqueue_scripts', 'letter_enqueue_frontend_assets');
function letter_enqueue_frontend_assets() {
    if (has_shortcode(get_the_content(), 'letter')) {
        wp_enqueue_style('letter-style', LETTER_URL . 'assets/css/letter-style.css', [], '3.6');
    }
}

// تاریخ شمسی
function get_current_persian_date() {
    $date = new DateTime();
    $formatter = new IntlDateFormatter(
        'fa_IR@calendar=persian',
        IntlDateFormatter::FULL,
        IntlDateFormatter::FULL,
        'Asia/Tehran',
        IntlDateFormatter::TRADITIONAL
    );
    $formatter->setPattern('yyyy/MM/dd');
    return $formatter->format($date);
}

// صفحه صدور نامه
function letter_issue_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'letters';

    // ذخیره نامه
    if (isset($_POST['submit_letter']) && check_admin_referer('letter_save_letter')) {
        $document_type = sanitize_text_field($_POST['document_type']);
        $document_class = sanitize_text_field($_POST['document_class']);
        $document_subject = sanitize_text_field($_POST['document_subject']);
        $last_letter = $wpdb->get_var($wpdb->prepare("SELECT MAX(id) FROM $table_name WHERE document_type = %s", $document_type));
        $number = str_pad($last_letter + 1, 4, '0', STR_PAD_LEFT);
        // شماره‌گذاری برعکس: نوع سند/کلاس/موضوع/شماره
        $letter_number = "$document_type/$document_class/$document_subject/$number";

        $data = [
            'letter_number' => $letter_number,
            'subject' => sanitize_text_field($_POST['subject']),
            'content' => wp_kses_post($_POST['content']),
            'recipient_name' => sanitize_text_field($_POST['recipient_name']),
            'recipient_position' => sanitize_text_field($_POST['recipient_position']),
            'sender_name' => sanitize_text_field($_POST['sender_name']),
            'sender_position' => sanitize_text_field($_POST['sender_position']),
            'signature_url' => esc_url_raw($_POST['signature_url']),
            'document_type' => $document_type,
            'document_class' => $document_class,
            'document_subject' => $document_subject,
            'status' => 'draft',
            'archived' => 0
        ];

        $result = $wpdb->insert($table_name, $data);
        if ($result) {
            echo '<div class="updated"><p>نامه با موفقیت ثبت شد!</p></div>';
        } else {
            echo '<div class="error"><p>خطا در ثبت نامه: ' . $wpdb->last_error . '</p></div>';
        }
    }

    // بایگانی کردن نامه
    if (isset($_POST['archive_letter']) && check_admin_referer('letter_archive_letter')) {
        $letter_id = intval($_POST['letter_id']);
        $wpdb->update($table_name, ['archived' => 1], ['id' => $letter_id]);
        echo '<div class="updated"><p>نامه با موفقیت بایگانی شد!</p></div>';
    }

    // نمایش فرم
    $document_types = [
        '25' => 'قرارداد',
        '04' => 'پرونده/رزومه/اسناد بایگانی',
        '07' => 'صورتجلسه',
        '29' => 'اسناد مالی',
        '30' => 'نامه اداری/سازمانی'
    ];

    $document_classes = [
        '1' => 'هیئت مدیره',
        '2' => 'اداره مالی',
        '3' => 'مدیران استودیو',
        '4' => 'مدیرمسئول نشریه',
        '5' => 'واحد تحقیق‌وتوسعه',
        '6' => 'روابط عمومی',
        '7' => 'منابع انسانی',
        '8' => 'فروش/پشتیبانی',
        '9' => 'کارمندان(عمومی)'
    ];

    $document_subjects = [
        '1' => 'پرونده‌های پرسنلی',
        '2' => 'صورتجلسه',
        '3' => 'اسناد مالی',
        '4' => 'قرارداد کارمندان',
        '5' => 'قرارداد کافرمایان',
        '6' => 'اسناد حقوقی',
        '7' => 'گزارش‌ها',
        '8' => 'درخواست‌ها'
    ];

    $letters = $wpdb->get_results("SELECT * FROM $table_name WHERE archived = 0 ORDER BY created_at DESC");
    ?>
    <div class="wrap letter-wrap">
        <h1>مدیریت نامه‌ها</h1>
        <div class="letter-content">
            <form method="post" class="letter-form">
                <?php wp_nonce_field('letter_save_letter'); ?>
                <div class="form-field number-field">
                    <label>شماره‌گذاری</label>
                    <div class="number-inputs">
                        <select name="document_type" required>
                            <?php foreach ($document_types as $code => $name) : ?>
                                <option value="<?php echo $code; ?>"><?php echo $name; ?></option>
                            <?php endforeach; ?>
                        </select>
                        <span>/</span>
                        <select name="document_class" required>
                            <?php foreach ($document_classes as $code => $name) : ?>
                                <option value="<?php echo $code; ?>"><?php echo $name; ?></option>
                            <?php endforeach; ?>
                        </select>
                        <span>/</span>
                        <select name="document_subject" required>
                            <?php foreach ($document_subjects as $code => $name) : ?>
                                <option value="<?php echo $code; ?>"><?php echo $name; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="form-field">
                    <label for="subject">موضوع نامه</label>
                    <input type="text" name="subject" id="subject" required>
                </div>
                <div class="form-field">
                    <label for="recipient_name">نام کامل گیرنده</label>
                    <input type="text" name="recipient_name" id="recipient_name" required>
                </div>
                <div class="form-field">
                    <label for="recipient_position">سمت گیرنده</label>
                    <input type="text" name="recipient_position" id="recipient_position" required>
                </div>
                <div class="form-field">
                    <label for="content">متن نامه</label>
                    <textarea name="content" id="content" rows="5" required></textarea>
                </div>
                <div class="form-field">
                    <label for="sender_name">نام کامل فرستنده</label>
                    <input type="text" name="sender_name" id="sender_name" required>
                </div>
                <div class="form-field">
                    <label for="sender_position">سمت فرستنده</label>
                    <input type="text" name="sender_position" id="sender_position" required>
                </div>
                <div class="form-field">
                    <label for="signature_url">آپلود امضا (اختیاری)</label>
                    <input type="hidden" name="signature_url" id="signature_url">
                    <button type="button" class="upload-signature button">آپلود امضا</button>
                </div>
                <button type="submit" name="submit_letter" class="letter-button">ذخیره نامه</button>
            </form>

            <h2>لیست نامه‌ها</h2>
            <table class="wp-list-table widefat striped">
                <thead>
                    <tr>
                        <th>شماره نامه</th>
                        <th>موضوع</th>
                        <th>گیرنده</th>
                        <th>تاریخ</th>
                        <th>عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($letters as $letter) : ?>
                        <tr>
                            <td><?php echo esc_html($letter->letter_number); ?></td>
                            <td><?php echo esc_html($letter->subject); ?></td>
                            <td><?php echo esc_html($letter->recipient_name); ?></td>
                            <td><?php echo get_current_persian_date(); ?></td>
                            <td>
                                <button class="print-letter button" data-letter-id="<?php echo $letter->id; ?>">پرینت</button>
                                <button class="download-image button" data-letter-id="<?php echo $letter->id; ?>">دانلود تصویر</button>
                                <button class="send-options button" data-letter-id="<?php echo $letter->id; ?>">ارسال</button>
                                <form method="post" style="display:inline;">
                                    <?php wp_nonce_field('letter_archive_letter'); ?>
                                    <input type="hidden" name="letter_id" value="<?php echo $letter->id; ?>">
                                    <button type="submit" name="archive_letter" class="button">بایگانی</button>
                                </form>
                                <div class="send-options-box" style="display:none;">
                                    <select class="send-method">
                                        <option value="print">پرینت</option>
                                        <option value="users">ارسال به کاربران</option>
                                        <option value="email">ارسال ایمیل</option>
                                    </select>
                                    <div class="users-box" style="display:none;">
                                        <select class="user-roles">
                                            <?php
                                            $roles = wp_roles()->get_names();
                                            foreach ($roles as $role => $name) {
                                                echo '<option value="' . $role . '">' . $name . '</option>';
                                            }
                                            ?>
                                        </select>
                                    </div>
                                    <div class="email-box" style="display:none;">
                                        <input type="email" class="email-input" placeholder="ایمیل گیرنده">
                                    </div>
                                    <button class="send-letter button-primary" data-letter-id="<?php echo $letter->id; ?>">ارسال</button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php
}

// صفحه بایگانی
function letter_archive_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'letters';

    $document_types = [
        '25' => 'قرارداد',
        '04' => 'پرونده/رزومه/اسناد بایگانی',
        '07' => 'صورتجلسه',
        '29' => 'اسناد مالی',
        '30' => 'نامه اداری/سازمانی'
    ];

    $letters = $wpdb->get_results("SELECT * FROM $table_name WHERE archived = 1 ORDER BY document_type, created_at DESC");
    ?>
    <div class="wrap letter-wrap">
        <h1>بایگانی نامه‌ها</h1>
        <div class="letter-content">
            <?php foreach ($document_types as $type_code => $type_name) : ?>
                <div class="archive-table">
                    <h2><?php echo $type_name; ?></h2>
                    <table class="wp-list-table widefat striped">
                        <thead>
                            <tr>
                                <th>شماره نامه</th>
                                <th>موضوع</th>
                                <th>گیرنده</th>
                                <th>تاریخ</th>
                                <th>عملیات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $filtered_letters = array_filter($letters, function($letter) use ($type_code) {
                                return $letter->document_type == $type_code;
                            });
                            if (empty($filtered_letters)) {
                                echo '<tr><td colspan="5">نامه‌ای یافت نشد.</td></tr>';
                            } else {
                                foreach ($filtered_letters as $letter) : ?>
                                    <tr>
                                        <td><?php echo esc_html($letter->letter_number); ?></td>
                                        <td><?php echo esc_html($letter->subject); ?></td>
                                        <td><?php echo esc_html($letter->recipient_name); ?></td>
                                        <td><?php echo get_current_persian_date(); ?></td>
                                        <td>
                                            <button class="view-letter button" data-letter-id="<?php echo $letter->id; ?>">مشاهده</button>
                                            <button class="print-letter button" data-letter-id="<?php echo $letter->id; ?>">پرینت</button>
                                            <button class="download-image button" data-letter-id="<?php echo $letter->id; ?>">دانلود تصویر</button>
                                        </td>
                                    </tr>
                                <?php endforeach;
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php
}

// شورت‌کد برای نمایش نامه
add_shortcode('letter', 'letter_shortcode');
function letter_shortcode($atts) {
    global $wpdb;
    $atts = shortcode_atts(['id' => 0], $atts);
    $letter = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}letters WHERE id = %d", $atts['id']));

    if (!$letter) return 'نامه یافت نشد.';

    ob_start();
    include LETTER_PATH . 'templates/letter-recipient.php';
    $html = ob_get_clean();

    // اضافه کردن پاورقی به ایمیل
    $footer_text = get_option('letter_footer_text', '');
    $logo_url = get_option('letter_logo_url', '');
    $footer_html = '';
    if ($footer_text || $logo_url) {
        $footer_html .= '<div class="email-footer">';
        if ($logo_url) {
            $footer_html .= '<img src="' . esc_url($logo_url) . '" alt="Logo" class="footer-logo">';
        }
        if ($footer_text) {
            $footer_html .= '<div class="footer-text">' . wpautop($footer_text) . '</div>';
        }
        $footer_html .= '</div>';
    }

    return $html . $footer_html;
}

// تولید تصویر
add_action('wp_ajax_letter_generate_image', 'letter_generate_image');
function letter_generate_image() {
    check_ajax_referer('letter_send_email', '_nonce');
    global $wpdb;

    $letter_id = intval($_POST['letter_id']);
    $letter = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}letters WHERE id = %d", $letter_id));

    if (!$letter) wp_send_json_error(['message' => 'نامه یافت نشد.']);

    // تولید HTML
    ob_start();
    include LETTER_PATH . 'templates/letter-recipient.php';
    $html = ob_get_clean();

    // استفاده از wkhtmltoimage (باید روی سرور نصب باشه)
    $upload_dir = wp_upload_dir();
    $output_file = $upload_dir['path'] . '/letter-' . $letter_id . '.png';
    $html_file = $upload_dir['path'] . '/letter-' . $letter_id . '.html';

    // ذخیره HTML موقت
    file_put_contents($html_file, $html);

    // تبدیل HTML به تصویر
    $command = "wkhtmltoimage --width 800 $html_file $output_file";
    exec($command);

    // حذف فایل HTML موقت
    unlink($html_file);

    if (file_exists($output_file)) {
        header('Content-Type: image/png');
        header('Content-Disposition: attachment; filename="letter-' . $letter_id . '.png"');
        readfile($output_file);
        unlink($output_file);
        exit;
    } else {
        wp_send_json_error(['message' => 'خطا در تولید تصویر.']);
    }
}

// ارسال ایمیل
add_action('wp_ajax_letter_send_email', 'letter_send_email');
function letter_send_email() {
    check_ajax_referer('letter_send_email', '_nonce');
    global $wpdb;

    $letter_id = intval($_POST['letter_id']);
    $email = sanitize_email($_POST['email']);
    $letter = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}letters WHERE id = %d", $letter_id));

    $subject = $letter->subject;
    $message = letter_shortcode(['id' => $letter_id]);

    // تنظیم نام و ایمیل فرستنده
    $site_name = get_bloginfo('name'); // نام سایت
    $site_domain = parse_url(get_site_url(), PHP_URL_HOST); // دامین سایت
    $from_name = $site_name; // مثلاً "تصویر سنتورس"
    $from_email = "info@$site_domain"; // مثلاً info@centauruspicture.ir

    $headers = [
        'Content-Type: text/html; charset=UTF-8',
        "From: $from_name <$from_email>"
    ];

    $sent = wp_mail($email, $subject, $message, $headers);

    wp_send_json([
        'success' => $sent,
        'data' => ['message' => $sent ? 'ایمیل با موفقیت ارسال شد!' : 'خطا در ارسال ایمیل.']
    ]);
}

// ارسال به کاربران
add_action('wp_ajax_letter_send_to_users', 'letter_send_to_users');
function letter_send_to_users() {
    check_ajax_referer('letter_send_email', '_nonce');
    global $wpdb;

    $letter_id = intval($_POST['letter_id']);
    $role = sanitize_text_field($_POST['role']);
    $letter = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}letters WHERE id = %d", $letter_id));

    $users = get_users(['role' => $role]);
    $sent = 0;

    // تنظیم نام و ایمیل فرستنده
    $site_name = get_bloginfo('name'); // نام سایت
    $site_domain = parse_url(get_site_url(), PHP_URL_HOST); // دامین سایت
    $from_name = $site_name; // مثلاً "تصویر سنتورس"
    $from_email = "info@$site_domain"; // مثلاً info@centauruspicture.ir

    $headers = [
        'Content-Type: text/html; charset=UTF-8',
        "From: $from_name <$from_email>"
    ];

    foreach ($users as $user) {
        $email = $user->user_email;
        $subject = $letter->subject;
        $message = letter_shortcode(['id' => $letter_id]);
        if (wp_mail($email, $subject, $message, $headers)) $sent++;
    }

    wp_send_json([
        'success' => $sent > 0,
        'data' => ['message' => "ایمیل به $sent کاربر ارسال شد!"]
    ]);
}

// صفحه پرینت و مشاهده
add_action('init', 'letter_print_page');
function letter_print_page() {
    if (isset($_GET['letter']) && isset($_GET['action']) && in_array($_GET['action'], ['print', 'view'])) {
        global $wpdb;
        $letter_id = intval($_GET['letter']);
        $letter = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}letters WHERE id = %d", $letter_id));

        if (!$letter) {
            wp_die('نامه یافت نشد.');
        }

        include LETTER_PATH . 'templates/letter-recipient.php';
        if ($_GET['action'] === 'print') {
            echo '<script>window.onload = function() { window.print(); }</script>';
        }
        exit;
    }
}