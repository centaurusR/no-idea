<?php
/**
 * Plugin Name: HireWire
 * Description: فرم استخدام با اتصال به همکار پلاس.
 * Version: 1.7
 * Author: YourName
 */

defined('ABSPATH') || exit;

// ساخت جدول دیتابیس و صفحه‌ی "فرم همکاری" موقع فعال‌سازی پلاگین
register_activation_hook(__FILE__, 'hirewire_setup');
function hirewire_setup() {
    hirewire_update_database();
    hirewire_create_form_page();
}

// تابع به‌روزرسانی دیتابیس
function hirewire_update_database() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'hirewire_resumes';
    $charset_collate = $wpdb->get_charset_collate();
    $current_db_version = get_option('hirewire_db_version', '0.0');
    $new_db_version = '1.1';

    $sql = "CREATE TABLE $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        form_data LONGTEXT DEFAULT '',
        archived TINYINT(1) DEFAULT 0,
        submitted_at DATETIME NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

    $columns = $wpdb->get_results("SHOW COLUMNS FROM $table_name");
    $has_form_data = false;
    foreach ($columns as $column) {
        if ($column->Field === 'form_data') {
            $has_form_data = true;
            break;
        }
    }

    if (!$has_form_data) {
        $wpdb->query("ALTER TABLE $table_name ADD COLUMN form_data LONGTEXT DEFAULT '' AFTER id");
    }

    if (version_compare($current_db_version, $new_db_version, '<')) {
        update_option('hirewire_db_version', $new_db_version);
    }
}

// تابع ساخت صفحه‌ی "فرم همکاری"
function hirewire_create_form_page() {
    $page = get_page_by_path('form-hamkari');
    if (!$page) {
        wp_insert_post(array(
            'post_title'    => 'فرم همکاری',
            'post_content'  => '[hirewire_form]',
            'post_status'   => 'publish',
            'post_type'     => 'page',
            'post_name'     => 'form-hamkari',
        ));
    }
}

// لود استایل‌ها و اسکریپت‌ها
add_action('admin_enqueue_scripts', 'hirewire_admin_assets');
add_action('wp_enqueue_scripts', 'hirewire_admin_assets');
function hirewire_admin_assets($hook) {
    global $pagenow;

    // لود استایل‌ها
    wp_enqueue_style('hirewire-style', plugin_dir_url(__FILE__) . 'hirewire-style.css');

    // فقط در صفحات مورد نیاز اسکریپت‌ها رو لود کن
    $is_admin_page = (is_admin() && in_array($pagenow, ['admin.php']) && isset($_GET['page']) && in_array($_GET['page'], ['hirewire-resumes', 'hirewire-form-builder', 'hirewire-archived']));
    $is_form_page = (is_page('form-hamkari') || isset($_GET['hirewire_print']));

    if (!$is_admin_page && !$is_form_page) {
        return;
    }

    wp_enqueue_script('jquery-ui-sortable');
    wp_enqueue_style('datatables-css', 'https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css');
    wp_enqueue_script('datatables-js', 'https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js', array('jquery'), '1.11.5', true);

    wp_add_inline_script('datatables-js', '
        jQuery(document).ready(function($) {
            $("#resumes-table").DataTable({
                "language": {
                    "url": "//cdn.datatables.net/plug-ins/1.11.5/i18n/fa.json"
                },
                "order": [[3, "desc"]],
                "pageLength": 10,
                "responsive": true
            });
        });
    ');

    // جاوااسکریپت
    wp_add_inline_script('jquery', '
        jQuery(document).ready(function($) {
            $("#field-list").sortable({
                handle: ".field-handle",
                update: function(event, ui) {
                    updateFieldNames();
                }
            });

            $("#add-field").on("click", function() {
                var index = $(".field-item").length;
                var fieldHtml = `
                    <div class="field-item">
                        <span class="field-handle">☰</span>
                        <select name="field_type[]" class="field-type">
                            <option value="text">متن</option>
                            <option value="email">ایمیل</option>
                            <option value="tel">تلفن</option>
                            <option value="textarea">متن بلند</option>
                            <option value="file">فایل</option>
                        </select>
                        <input type="text" name="field_label[]" placeholder="برچسب" required>
                        <input type="text" name="field_name[]" placeholder="نام (انگلیسی)" required>
                        <label class="hirewire-checkbox">
                            <input type="checkbox" name="field_required[]"> الزامی
                        </label>
                        <button type="button" class="hirewire-button hirewire-button-danger remove-field">حذف</button>
                    </div>
                `;
                $("#field-list").append(fieldHtml);
                updateFieldNames();
            });

            $(document).on("click", ".remove-field", function() {
                $(this).closest(".field-item").remove();
                updateFieldNames();
            });

            function updateFieldNames() {
                $(".field-item").each(function(index) {
                    $(this).find("input[name^=\"field_required\"]").attr("name", `field_required[${index}]`);
                });
            }

            $(document).on("click", ".hirewire-view-details", function(e) {
                e.preventDefault();
                var id = $(this).data("id");
                var modal = $("#hirewire-modal");
                var modalBody = $("#hirewire-modal-body");

                $.ajax({
                    url: ajaxurl,
                    type: "POST",
                    data: {
                        action: "hirewire_get_resume_details",
                        id: id,
                        nonce: "' . wp_create_nonce('hirewire_get_resume_details_nonce') . '"
                    },
                    success: function(response) {
                        modalBody.html(response);
                        modal.show();
                    },
                    error: function(xhr, status, error) {
                        modalBody.html("خطا در بارگذاری جزئیات: " + error);
                        modal.show();
                    }
                });
            });

            $(".hirewire-modal-close").on("click", function() {
                $("#hirewire-modal").hide();
            });

            $(window).on("click", function(event) {
                if (event.target == $("#hirewire-modal")[0]) {
                    $("#hirewire-modal").hide();
                }
            });

            $(document).on("click", ".hirewire-print", function(e) {
                e.preventDefault();
                var id = $(this).data("id");
                window.open("?hirewire_print=" + id, "_blank");
            });
        });
    ');
}

// نمایش فرم در فرانت‌اند
add_shortcode('hirewire_form', 'hirewire_display_form');
function hirewire_display_form() {
    $fields = get_option('hirewire_form_fields', array(
        array('type' => 'tel', 'label' => 'شماره تماس', 'name' => 'phone', 'required' => true),
        array('type' => 'text', 'label' => 'آخرین مدرک تحصیلی', 'name' => 'education', 'required' => true),
        array('type' => 'text', 'label' => 'نام دانشگاه', 'name' => 'university', 'required' => true),
        array('type' => 'text', 'label' => 'عنوان شغلی مورد نظر', 'name' => 'job_title', 'required' => true),
        array('type' => 'text', 'label' => 'نام شرکت/واحد صنفی', 'name' => 'company_name', 'required' => true),
        array('type' => 'text', 'label' => 'مدت زمان', 'name' => 'duration', 'required' => true),
        array('type' => 'text', 'label' => 'مهارت ۱', 'name' => 'skill_1', 'required' => false),
        array('type' => 'text', 'label' => 'مهارت ۲', 'name' => 'skill_2', 'required' => false),
        array('type' => 'text', 'label' => 'مهارت ۳', 'name' => 'skill_3', 'required' => false),
        array('type' => 'text', 'label' => 'مهارت ۴', 'name' => 'skill_4', 'required' => false),
        array('type' => 'textarea', 'label' => 'رزومه (متن)', 'name' => 'resume_text', 'required' => true),
        array('type' => 'file', 'label' => 'ارسال فایل رزومه', 'name' => 'resume_file', 'required' => false),
    ));

    ob_start(); ?>
    <div class="hirewire-container">
        <h2 class="hirewire-title">فرم همکاری</h2>
        <form class="hirewire-form" method="post" enctype="multipart/form-data">
            <?php wp_nonce_field('hirewire_form_submit', 'hirewire_nonce'); ?>
            <?php
            $current_section = '';
            foreach ($fields as $field):
                if (in_array($field['name'], ['company_name'])) {
                    if ($current_section !== 'experience') {
                        echo '<h3 class="hirewire-section-title">سوابق شغلی</h3>';
                        $current_section = 'experience';
                    }
                } elseif (in_array($field['name'], ['skill_1'])) {
                    if ($current_section !== 'skills') {
                        echo '<h3 class="hirewire-section-title">مهارت‌ها</h3>';
                        $current_section = 'skills';
                    }
                } elseif (in_array($field['name'], ['resume_text'])) {
                    if ($current_section !== 'resume') {
                        echo '<h3 class="hirewire-section-title">رزومه</h3>';
                        $current_section = 'resume';
                    }
                }
            ?>
                <div class="form-field">
                    <label class="hirewire-label"><?php echo esc_html($field['label']); ?><?php echo $field['required'] ? ' <span class="required">*</span>' : ''; ?></label>
                    <?php if ($field['type'] === 'textarea'): ?>
                        <textarea name="<?php echo esc_attr($field['name']); ?>" class="hirewire-input" <?php echo $field['required'] ? 'required' : ''; ?>></textarea>
                    <?php elseif ($field['type'] === 'file'): ?>
                        <input type="file" name="<?php echo esc_attr($field['name']); ?>" class="hirewire-input" <?php echo $field['required'] ? 'required' : ''; ?>>
                    <?php else: ?>
                        <input type="<?php echo esc_attr($field['type']); ?>" name="<?php echo esc_attr($field['name']); ?>" class="hirewire-input" <?php echo $field['required'] ? 'required' : ''; ?>>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
            <button type="submit" name="hirewire_submit" class="hirewire-button hirewire-button-primary">ثبت</button>
        </form>
    </div>
    <?php
    if (isset($_POST['hirewire_submit'])) {
        // بررسی nonce برای امنیت
        if (!isset($_POST['hirewire_nonce']) || !wp_verify_nonce($_POST['hirewire_nonce'], 'hirewire_form_submit')) {
            echo '<div class="hirewire-error">خطا در اعتبارسنجی فرم. لطفاً دوباره تلاش کنید.</div>';
            error_log('HireWire: خطا در اعتبارسنجی nonce');
            return ob_get_clean();
        }

        global $wpdb;
        $table = $wpdb->prefix . 'hirewire_resumes';

        // بررسی وجود جدول
        if ($wpdb->get_var("SHOW TABLES LIKE '$table'") != $table) {
            echo '<div class="hirewire-error">جدول دیتابیس وجود ندارد. لطفاً پلاگین را غیرفعال و دوباره فعال کنید.</div>';
            error_log('HireWire: جدول دیتابیس وجود ندارد - ' . $table);
            return ob_get_clean();
        }

        // بررسی وجود ستون form_data
        $columns = $wpdb->get_results("SHOW COLUMNS FROM $table");
        $has_form_data = false;
        foreach ($columns as $column) {
            if ($column->Field === 'form_data') {
                $has_form_data = true;
                break;
            }
        }

        if (!$has_form_data) {
            echo '<div class="hirewire-error">ستون form_data در جدول دیتابیس وجود ندارد. لطفاً پلاگین را غیرفعال و دوباره فعال کنید.</div>';
            error_log('HireWire: ستون form_data وجود ندارد');
            return ob_get_clean();
        }

        // پردازش داده‌های فرم
        $form_data = array();
        foreach ($fields as $field) {
            $field_name = $field['name'];
            if ($field['type'] === 'file' && isset($_FILES[$field_name]) && $_FILES[$field_name]['size'] > 0) {
                $upload = wp_handle_upload($_FILES[$field_name], array('test_form' => false));
                if (isset($upload['error'])) {
                    echo '<div class="hirewire-error">خطا در آپلود فایل: ' . esc_html($upload['error']) . '</div>';
                    error_log('HireWire: خطا در آپلود فایل - ' . $upload['error']);
                    return ob_get_clean();
                }
                $form_data[$field_name] = $upload['url'];
            } elseif (isset($_POST[$field_name]) && !empty($_POST[$field_name])) {
                if ($field['type'] === 'email') {
                    $form_data[$field_name] = sanitize_email($_POST[$field_name]);
                } elseif ($field['type'] === 'textarea') {
                    $form_data[$field_name] = sanitize_textarea_field($_POST[$field_name]);
                } else {
                    $form_data[$field_name] = sanitize_text_field($_POST[$field_name]);
                }
            } else {
                $form_data[$field_name] = ''; // برای فیلدهای خالی
            }
        }

        // ثبت داده‌ها در دیتابیس
        $data_to_insert = array(
            'form_data' => wp_json_encode($form_data, JSON_UNESCAPED_UNICODE),
            'archived'  => 0,
            'submitted_at' => current_time('mysql')
        );

        $result = $wpdb->insert($table, $data_to_insert, array('%s', '%d', '%s'));

        if ($result === false) {
            echo '<div class="hirewire-error">خطا در ثبت رزومه: ' . esc_html($wpdb->last_error) . '</div>';
            error_log('HireWire: خطا در ثبت رزومه - ' . $wpdb->last_error);
            error_log('HireWire: داده‌های ارسالی - ' . print_r($data_to_insert, true));
        } else {
            echo '<div class="hirewire-success">رزومه شما با موفقیت ارسال شد.</div>';
            error_log('HireWire: رزومه با موفقیت ثبت شد - ID: ' . $wpdb->insert_id);
            // رفرش صفحه برای جلوگیری از ارسال مجدد فرم
            echo '<script>window.location.href = window.location.href;</script>';
        }
    }
    return ob_get_clean();
}

// تابع چاپ رزومه
add_action('init', 'hirewire_handle_print');
function hirewire_handle_print() {
    if (isset($_GET['hirewire_print'])) {
        $id = intval($_GET['hirewire_print']);
        global $wpdb;
        $table = $wpdb->prefix . 'hirewire_resumes';
        $resume = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id = %d", $id));

        if (!$resume) {
            wp_die('رزومه یافت نشد.');
        }

        $form_data = json_decode($resume->form_data, true);
        $fields = get_option('hirewire_form_fields', array());

        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>چاپ رزومه</title>
            <?php wp_head(); ?>
            <script>
                window.onload = function() {
                    window.print();
                };
            </script>
        </head>
        <body class="rtl">
            <div class="hirewire-print-container hirewire-container">
                <h2 class="hirewire-title">رزومه</h2>
                <?php
                $current_section = '';
                foreach ($fields as $field) {
                    if (in_array($field['name'], ['company_name'])) {
                        if ($current_section !== 'experience') {
                            echo '<h3 class="hirewire-section-title">سوابق شغلی</h3>';
                            $current_section = 'experience';
                        }
                    } elseif (in_array($field['name'], ['skill_1'])) {
                        if ($current_section !== 'skills') {
                            echo '<h3 class="hirewire-section-title">مهارت‌ها</h3>';
                            $current_section = 'skills';
                        }
                    } elseif (in_array($field['name'], ['resume_text'])) {
                        if ($current_section !== 'resume') {
                            echo '<h3 class="hirewire-section-title">رزومه</h3>';
                            $current_section = 'resume';
                        }
                    }

                    if (isset($form_data[$field['name']])) {
                        ?>
                        <div class="form-field">
                            <label class="hirewire-label"><?php echo esc_html($field['label']); ?>:</label>
                            <?php if ($field['type'] === 'file' && $form_data[$field['name']]): ?>
                                <a href="<?php echo esc_url($form_data[$field['name']]); ?>" target="_blank">دانلود فایل</a>
                            <?php else: ?>
                                <p><?php echo nl2br(esc_html($form_data[$field['name']])); ?></p>
                            <?php endif; ?>
                        </div>
                        <?php
                    }
                }
                ?>
                <p><strong>تاریخ ارسال:</strong> <?php echo esc_html($resume->submitted_at); ?></p>
            </div>
        </body>
        </html>
        <?php
        exit;
    }
}

// منوی ادمین
add_action('admin_menu', 'hirewire_admin_menu');
function hirewire_admin_menu() {
    add_menu_page(
        'رزومه‌ها',
        'رزومه‌ها',
        'manage_options',
        'hirewire-resumes',
        'hirewire_display_resumes',
        'dashicons-id-alt',
        26
    );

    add_submenu_page(
        'hirewire-resumes',
        'رزومه‌های بایگانی‌شده',
        'بایگانی‌شده‌ها',
        'manage_options',
        'hirewire-archived',
        'hirewire_display_archived_resumes'
    );

    add_submenu_page(
        'hirewire-resumes',
        'فرم‌ساز استخدام',
        'فرم‌ساز',
        'manage_options',
        'hirewire-form-builder',
        'hirewire_form_builder_page'
    );
}

// صفحه‌ی فرم‌ساز
function hirewire_form_builder_page() {
    if (isset($_POST['hirewire_save_form']) && check_admin_referer('hirewire_save_form')) {
        $fields = array();
        if (isset($_POST['field_type'])) {
            foreach ($_POST['field_type'] as $index => $type) {
                $fields[] = array(
                    'type' => sanitize_text_field($type),
                    'label' => sanitize_text_field($_POST['field_label'][$index]),
                    'name' => sanitize_text_field($_POST['field_name'][$index]),
                    'required' => isset($_POST['field_required'][$index]) ? 1 : 0,
                );
            }
        }
        update_option('hirewire_form_fields', $fields);
        echo '<div class="hirewire-success">فرم با موفقیت ذخیره شد.</div>';
    }

    $fields = get_option('hirewire_form_fields', array(
        array('type' => 'tel', 'label' => 'شماره تماس', 'name' => 'phone', 'required' => true),
        array('type' => 'text', 'label' => 'آخرین مدرک تحصیلی', 'name' => 'education', 'required' => true),
        array('type' => 'text', 'label' => 'نام دانشگاه', 'name' => 'university', 'required' => true),
        array('type' => 'text', 'label' => 'عنوان شغلی مورد نظر', 'name' => 'job_title', 'required' => true),
        array('type' => 'text', 'label' => 'نام شرکت/واحد صنفی', 'name' => 'company_name', 'required' => true),
        array('type' => 'text', 'label' => 'مدت زمان', 'name' => 'duration', 'required' => true),
        array('type' => 'text', 'label' => 'مهارت ۱', 'name' => 'skill_1', 'required' => false),
        array('type' => 'text', 'label' => 'مهارت ۲', 'name' => 'skill_2', 'required' => false),
        array('type' => 'text', 'label' => 'مهارت ۳', 'name' => 'skill_3', 'required' => false),
        array('type' => 'text', 'label' => 'مهارت ۴', 'name' => 'skill_4', 'required' => false),
        array('type' => 'textarea', 'label' => 'رزومه (متن)', 'name' => 'resume_text', 'required' => true),
        array('type' => 'file', 'label' => 'ارسال فایل رزومه', 'name' => 'resume_file', 'required' => false),
    ));
    ?>
    <div class="hirewire-wrap">
        <h1>فرم‌ساز استخدام</h1>
        <div class="form-builder-container">
            <div class="field-list">
                <h2>مدیریت فیلدها</h2>
                <form method="post">
                    <?php wp_nonce_field('hirewire_save_form'); ?>
                    <div id="field-list" class="sortable">
                        <?php foreach ($fields as $index => $field): ?>
                            <div class="field-item">
                                <span class="field-handle">☰</span>
                                <select name="field_type[]" class="field-type">
                                    <option value="text" <?php selected($field['type'], 'text'); ?>>متن</option>
                                    <option value="email" <?php selected($field['type'], 'email'); ?>>ایمیل</option>
                                    <option value="tel" <?php selected($field['type'], 'tel'); ?>>تلفن</option>
                                    <option value="textarea" <?php selected($field['type'], 'textarea'); ?>>متن بلند</option>
                                    <option value="file" <?php selected($field['type'], 'file'); ?>>فایل</option>
                                </select>
                                <input type="text" name="field_label[]" value="<?php echo esc_attr($field['label']); ?>" placeholder="برچسب" required>
                                <input type="text" name="field_name[]" value="<?php echo esc_attr($field['name']); ?>" placeholder="نام (انگلیسی)" required>
                                <label class="hirewire-checkbox">
                                    <input type="checkbox" name="field_required[<?php echo $index; ?>]" <?php checked($field['required'], 1); ?>> الزامی
                                </label>
                                <button type="button" class="hirewire-button hirewire-button-danger remove-field">حذف</button>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <button type="button" id="add-field" class="hirewire-button hirewire-button-primary">افزودن فیلد</button>
                    <p class="submit">
                        <button type="submit" name="hirewire_save_form" class="hirewire-button hirewire-button-primary">ذخیره فرم</button>
                    </p>
                </form>
            </div>
        </div>
    </div>
    <?php
}

// نمایش رزومه‌ها در پنل مدیریت
function hirewire_display_resumes() {
    global $wpdb;
    $table = $wpdb->prefix . 'hirewire_resumes';
    $resumes = $wpdb->get_results("SELECT * FROM $table WHERE archived = 0 ORDER BY submitted_at DESC");
    ?>
    <div class="hirewire-wrap">
        <h1>رزومه‌های دریافتی</h1>
        <table id="resumes-table" class="hirewire-table">
            <thead>
                <tr>
                    <th>شماره تماس</th>
                    <th>آخرین مدرک</th>
                    <th>عنوان شغلی</th>
                    <th>تاریخ</th>
                    <th>عملیات</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($resumes as $r): 
                $form_data = json_decode($r->form_data, true);
                $phone = isset($form_data['phone']) ? $form_data['phone'] : '-';
                $education = isset($form_data['education']) ? $form_data['education'] : '-';
                $job_title = isset($form_data['job_title']) ? $form_data['job_title'] : '-';
            ?>
                <tr>
                    <td><?= esc_html($phone) ?></td>
                    <td><?= esc_html($education) ?></td>
                    <td><?= esc_html($job_title) ?></td>
                    <td><?= esc_html($r->submitted_at) ?></td>
                    <td>
                        <a href="#" class="button hirewire-view-details" data-id="<?= $r->id ?>">مشاهده</a>
                        <a href="#" class="button hirewire-print" data-id="<?= $r->id ?>">چاپ</a>
                        <form method="post" style="display:inline;">
                            <input type="hidden" name="archive_id" value="<?= $r->id ?>">
                            <button type="submit" name="hirewire_archive" class="button button-secondary">بایگانی</button>
                        </form>
                        <form method="post" style="display:inline;">
                            <input type="hidden" name="delete_id" value="<?= $r->id ?>">
                            <button type="submit" name="hirewire_delete" class="button hirewire-button-danger" onclick="return confirm('آیا مطمئن هستید که می‌خواهید این رزومه را حذف کنید؟')">حذف</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div id="hirewire-modal" class="hirewire-modal">
        <div class="hirewire-modal-content">
            <span class="hirewire-modal-close">×</span>
            <h2>جزئیات رزومه</h2>
            <div id="hirewire-modal-body"></div>
        </div>
    </div>

    <?php
    if (isset($_POST['hirewire_archive'])) {
        $id = intval($_POST['archive_id']);
        $wpdb->update($table, ['archived' => 1], ['id' => $id]);
        echo '<div class="hirewire-success">رزومه با موفقیت بایگانی شد.</div>';
        echo "<script>location.reload();</script>";
    }

    if (isset($_POST['hirewire_delete'])) {
        $id = intval($_POST['delete_id']);
        $wpdb->delete($table, ['id' => $id]);
        echo '<div class="hirewire-success">رزومه با موفقیت حذف شد.</div>';
        echo "<script>location.reload();</script>";
    }
}

// نمایش رزومه‌های بایگانی‌شده
function hirewire_display_archived_resumes() {
    global $wpdb;
    $table = $wpdb->prefix . 'hirewire_resumes';
    $resumes = $wpdb->get_results("SELECT * FROM $table WHERE archived = 1 ORDER BY submitted_at DESC");
    ?>
    <div class="hirewire-wrap">
        <h1>رزومه‌های بایگانی‌شده</h1>
        <table id="resumes-table" class="hirewire-table">
            <thead>
                <tr>
                    <th>شماره تماس</th>
                    <th>آخرین مدرک</th>
                    <th>عنوان شغلی</th>
                    <th>تاریخ</th>
                    <th>عملیات</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($resumes as $r): 
                $form_data = json_decode($r->form_data, true);
                $phone = isset($form_data['phone']) ? $form_data['phone'] : '-';
                $education = isset($form_data['education']) ? $form_data['education'] : '-';
                $job_title = isset($form_data['job_title']) ? $form_data['job_title'] : '-';
            ?>
                <tr>
                    <td><?= esc_html($phone) ?></td>
                    <td><?= esc_html($education) ?></td>
                    <td><?= esc_html($job_title) ?></td>
                    <td><?= esc_html($r->submitted_at) ?></td>
                    <td>
                        <a href="#" class="button hirewire-view-details" data-id="<?= $r->id ?>">مشاهده</a>
                        <a href="#" class="button hirewire-print" data-id="<?= $r->id ?>">چاپ</a>
                        <form method="post" style="display:inline;">
                            <input type="hidden" name="delete_id" value="<?= $r->id ?>">
                            <button type="submit" name="hirewire_delete" class="button hirewire-button-danger" onclick="return confirm('آیا مطمئن هستید که می‌خواهید این رزومه را حذف کنید؟')">حذف</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div id="hirewire-modal" class="hirewire-modal">
        <div class="hirewire-modal-content">
            <span class="hirewire-modal-close">×</span>
            <h2>جزئیات رزومه</h2>
            <div id="hirewire-modal-body"></div>
        </div>
    </div>

    <?php
    if (isset($_POST['hirewire_delete'])) {
        $id = intval($_POST['delete_id']);
        $wpdb->delete($table, ['id' => $id]);
        echo '<div class="hirewire-success">رزومه با موفقیت حذف شد.</div>';
        echo "<script>location.reload();</script>";
    }
}

// Ajax برای نمایش جزئیات رزومه
add_action('wp_ajax_hirewire_get_resume_details', 'hirewire_get_resume_details');
function hirewire_get_resume_details() {
    // بررسی nonce برای امنیت
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'hirewire_get_resume_details_nonce')) {
        wp_send_json_error('خطا در اعتبارسنجی درخواست.');
        wp_die();
    }

    global $wpdb;
    $id = intval($_POST['id']);
    $table = $wpdb->prefix . 'hirewire_resumes';
    $resume = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id = %d", $id));

    if ($resume) {
        $form_data = json_decode($resume->form_data, true);
        ob_start();
        if ($form_data) {
            $fields = get_option('hirewire_form_fields', array());
            $current_section = '';
            foreach ($fields as $field) {
                if (in_array($field['name'], ['company_name'])) {
                    if ($current_section !== 'experience') {
                        echo '<h3 class="hirewire-section-title">سوابق شغلی</h3>';
                        $current_section = 'experience';
                    }
                } elseif (in_array($field['name'], ['skill_1'])) {
                    if ($current_section !== 'skills') {
                        echo '<h3 class="hirewire-section-title">مهارت‌ها</h3>';
                        $current_section = 'skills';
                    }
                } elseif (in_array($field['name'], ['resume_text'])) {
                    if ($current_section !== 'resume') {
                        echo '<h3 class="hirewire-section-title">رزومه</h3>';
                        $current_section = 'resume';
                    }
                }

                if (isset($form_data[$field['name']])) {
                    ?>
                    <p><strong><?php echo esc_html($field['label']); ?>:</strong>
                    <?php if ($field['type'] === 'file' && $form_data[$field['name']]): ?>
                        <a href="<?php echo esc_url($form_data[$field['name']]); ?>" target="_blank">دانلود فایل</a>
                    <?php else: ?>
                        <?php echo nl2br(esc_html($form_data[$field['name']])); ?>
                    <?php endif; ?>
                    </p>
                    <?php
                }
            }
        }
        ?>
        <p><strong>تاریخ ارسال:</strong> <?= esc_html($resume->submitted_at) ?></p>
        <?php
        echo ob_get_clean();
    } else {
        echo 'رزومه یافت نشد.';
    }
    wp_die();
}