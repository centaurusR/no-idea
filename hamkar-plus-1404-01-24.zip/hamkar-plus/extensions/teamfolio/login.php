<?php
if (!defined('ABSPATH')) exit;

function teamfolio_create_login_attempts_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'teamfolio_login_attempts';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        ip_address VARCHAR(45) NOT NULL,
        username VARCHAR(100) NOT NULL,
        attempt_time DATETIME NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}
register_activation_hook(__FILE__, 'teamfolio_create_login_attempts_table');

function teamfolio_check_honeypot($data) {
    return !empty($data['teamfolio_email']);
}

function teamfolio_check_ip($ip) {
    $blocked_ips = explode(',', get_option('teamfolio_blocked_ips', ''));
    $blocked_ips = array_map('trim', $blocked_ips);
    return !in_array($ip, $blocked_ips);
}

function teamfolio_check_brute_force($ip, $username) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'teamfolio_login_attempts';
    $threshold = date('Y-m-d H:i:s', time() - 600);

    $attempts = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $table_name WHERE ip_address = %s AND username = %s AND attempt_time > %s",
        $ip, $username, $threshold
    ));

    return $attempts < 3;
}

function teamfolio_log_attempt($ip, $username) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'teamfolio_login_attempts';
    $wpdb->insert($table_name, [
        'ip_address' => $ip,
        'username' => $username,
        'attempt_time' => current_time('mysql')
    ]);
}

function teamfolio_render_login_form() {
    $error = '';
    if (isset($_POST['teamfolio_login']) && isset($_POST['teamfolio_login_nonce'])) {
        if (!wp_verify_nonce($_POST['teamfolio_login_nonce'], 'teamfolio_login')) {
            $error = 'خطای امنیتی!';
        } else {
            $username = sanitize_user($_POST['teamfolio_username']);
            $password = $_POST['teamfolio_password'];
            $honeypot = $_POST['teamfolio_email'];
            $ip = $_SERVER['REMOTE_ADDR'];

            if (teamfolio_check_honeypot($_POST)) {
                $error = 'درخواست مشکوک!';
            } elseif (!teamfolio_check_ip($ip)) {
                $error = 'دسترسی از این IP محدود است.';
            } elseif (!teamfolio_check_brute_force($ip, $username)) {
                $error = 'تلاش‌های زیاد! ۱۰ دقیقه دیگر امتحان کنید.';
            } else {
                $user = wp_authenticate($username, $password);
                if (is_wp_error($user)) {
                    $error = 'نام کاربری یا رمز اشتباه است.';
                    teamfolio_log_attempt($ip, $username);
                } else {
                    wp_set_auth_cookie($user->ID);
                    wp_redirect(admin_url('admin.php?page=hamkar_plus'));
                    exit;
                }
            }
        }
    }

    ob_start();
    ?>
    <div class="teamfolio-login-form">
        <?php if ($error): ?>
            <p class="shared-error"><?php echo esc_html($error); ?></p>
        <?php endif; ?>
        <form method="post">
            <div class="shared-form-field">
                <label for="teamfolio_username">نام کاربری</label>
                <input type="text" name="teamfolio_username" id="teamfolio_username" required>
            </div>
            <div class="shared-form-field">
                <label for="teamfolio_password">رمز عبور</label>
                <input type="password" name="teamfolio_password" id="teamfolio_password" required>
            </div>
            <div style="display:none;">
                <input type="text" name="teamfolio_email" id="teamfolio_email">
            </div>
            <?php wp_nonce_field('teamfolio_login', 'teamfolio_login_nonce'); ?>
            <button type="submit" name="teamfolio_login" class="shared-btn teamfolio-login-btn">ورود</button>
        </form>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('teamfolio_login', 'teamfolio_render_login_form');

add_action('init', function () {
    $page_slug = 'teamfolio-login';
    $page = get_page_by_path($page_slug, OBJECT, 'page');
    if (!$page) {
        $page_id = wp_insert_post([
            'post_title'   => 'تصویر سنتورس',
            'post_name'    => $page_slug,
            'post_content' => '[teamfolio_login]',
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_author'  => get_current_user_id() ?: 1,
        ], true);
    }
});