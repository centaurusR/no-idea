jQuery(document).ready(function($) {
    function createParticles() {
        const chart = $('.teamfolio-chart');
        for (let i = 0; i < 10; i++) {
            let particle = $('<div class="shared-particle"></div>');
            particle.css({
                left: Math.random() * 100 + '%',
                animationDelay: Math.random() * 5 + 's'
            });
            chart.append(particle);
        }
    }
    if ($('.teamfolio-chart').length) {
        createParticles();
    }

    $('#teamfolio_add_new_role_btn').click(function() {
        window.sharedToggle('teamfolio_new_role_row');
        $('#teamfolio_role').val('');
    });

    $('#teamfolio_role').change(function() {
        $('#teamfolio_new_role_row').hide();
        $('#teamfolio_position').val($(this).val());
    });

    $('#teamfolio_new_role').on('input', function() {
        $('#teamfolio_position').val($(this).val());
    });
});