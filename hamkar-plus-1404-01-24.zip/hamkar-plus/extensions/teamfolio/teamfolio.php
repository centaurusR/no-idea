<?php
/*
Plugin Name: Teamfolio
Description: مدیریت ساختار تیمی و کاربران داخلی
Version: 2.3
Author: تصویر سنتورس
Author URI: https://centauruspicture.ir/
License: GPL-2.0+
*/

if (!defined('ABSPATH')) exit;

require_once plugin_dir_path(__FILE__) . 'login.php';

add_action('admin_enqueue_scripts', function ($hook) {
    $teamfolio_pages = ['toplevel_page_teamfolio', 'teamfolio_page_teamfolio-settings', 'edit-teamfolio_personnel', 'teamfolio_personnel'];
    if (strpos($hook, 'teamfolio') !== false || in_array($hook, $teamfolio_pages)) {
        wp_enqueue_style('hamkar-shared-style', plugins_url('hamkar-plus/assets/css/shared-style.css'), [], '1.0');
        wp_enqueue_style('teamfolio-admin-style', plugin_dir_url(__FILE__) . 'assets/css/admin-style.css', [], '2.3');
        wp_enqueue_script('hamkar-shared-script', plugins_url('hamkar-plus/assets/js/shared-script.js'), ['jquery'], '1.0', true);
        wp_enqueue_script('teamfolio-script', plugin_dir_url(__FILE__) . 'assets/js/script.js', ['jquery', 'hamkar-shared-script'], '2.3', true);
    }
});

add_action('wp_enqueue_scripts', function () {
    if (is_page(['teamfolio-login', 'org-chart']) || has_shortcode(get_post()->post_content, 'teamfolio_chart')) {
        wp_enqueue_style('hamkar-shared-style', plugins_url('hamkar-plus/assets/css/shared-style.css'), [], '1.0');
        wp_enqueue_style('teamfolio-style', plugin_dir_url(__FILE__) . 'assets/css/style.css', [], '2.3');
        wp_enqueue_script('hamkar-shared-script', plugins_url('hamkar-plus/assets/js/shared-script.js'), ['jquery'], '1.0', true);
        wp_enqueue_script('teamfolio-script', plugin_dir_url(__FILE__) . 'assets/js/script.js', ['jquery', 'hamkar-shared-script'], '2.3', true);
    }
});

add_action('admin_menu', function () {
    add_menu_page(
        'تیم‌فولیو',
        'تیم‌فولیو',
        'manage_options',
        'teamfolio',
        'teamfolio_render_admin_page',
        'dashicons-groups',
        20
    );

    add_submenu_page(
        'teamfolio',
        'داشبورد تیم‌فولیو',
        'داشبورد',
        'manage_options',
        'teamfolio',
        'teamfolio_render_admin_page'
    );

    add_submenu_page(
        'teamfolio',
        'تنظیمات تیم‌فولیو',
        'تنظیمات',
        'manage_options',
        'teamfolio-settings',
        'teamfolio_render_settings_page'
    );

    add_submenu_page(
        'teamfolio',
        'پرسنل',
        'پرسنل',
        'manage_options',
        'edit.php?post_type=teamfolio_personnel'
    );

    add_submenu_page(
        'teamfolio',
        'دسته‌های پرسنل',
        'دسته‌های پرسنل',
        'manage_options',
        'edit-tags.php?taxonomy=teamfolio_personnel_category&post_type=teamfolio_personnel'
    );
});

add_action('init', 'teamfolio_register_personnel_post_type');
function teamfolio_register_personnel_post_type() {
    register_post_type('teamfolio_personnel', [
        'labels' => [
            'name' => 'پرسنل',
            'singular_name' => 'پرسنل',
            'add_new' => 'افزودن پرسنل',
            'add_new_item' => 'افزودن پرسنل جدید',
            'edit_item' => 'ویرایش پرسنل',
            'new_item' => 'پرسنل جدید',
            'view_item' => 'مشاهده پرسنل',
            'search_items' => 'جستجوی پرسنل',
            'not_found' => 'پرسنلی یافت نشد',
            'not_found_in_trash' => 'در زباله‌دان چیزی نیست'
        ],
        'public' => true,
        'show_in_menu' => false,
        'supports' => ['title', 'editor', 'thumbnail'],
        'show_in_rest' => true,
        'rewrite' => ['slug' => 'teamfolio-personnel']
    ]);

    register_taxonomy('teamfolio_personnel_category', 'teamfolio_personnel', [
        'labels' => [
            'name' => 'دسته‌های پرسنل',
            'singular_name' => 'دسته پرسنل',
            'search_items' => 'جستجوی دسته',
            'all_items' => 'تمام دسته‌ها',
            'edit_item' => 'ویرایش دسته',
            'update_item' => 'بروزرسانی دسته',
            'add_new_item' => 'افزودن دسته جدید',
            'new_item_name' => 'نام دسته جدید',
            'menu_name' => 'دسته‌های پرسنل'
        ],
        'public' => true,
        'hierarchical' => true,
        'show_in_rest' => true
    ]);
}

add_action('add_meta_boxes', 'teamfolio_add_personnel_meta_box');
function teamfolio_add_personnel_meta_box() {
    add_meta_box(
        'teamfolio_personnel_details',
        'اطلاعات پرسنل',
        'teamfolio_personnel_meta_box_callback',
        'teamfolio_personnel',
        'normal',
        'high'
    );
}

function teamfolio_personnel_meta_box_callback($post) {
    wp_nonce_field('teamfolio_personnel_meta_box', 'teamfolio_personnel_meta_box_nonce');
    $fields = [
        'position' => ['label' => 'سمت', 'type' => 'text'],
        'code' => ['label' => 'کد پرسنلی', 'type' => 'text'],
        'date' => ['label' => 'تاریخ ثبت', 'type' => 'date'],
        'email' => ['label' => 'ایمیل سازمانی', 'type' => 'email'],
        'phone' => ['label' => 'شماره تماس', 'type' => 'tel'],
        'fax' => ['label' => 'شماره فکس', 'type' => 'tel'],
        'unit' => ['label' => 'واحد/دپارتمان', 'type' => 'text'],
        'resume' => ['label' => 'لینک رزومه یا سند', 'type' => 'url'],
        'postal_code' => ['label' => 'کد پستی', 'type' => 'text'],
        'start_date' => ['label' => 'تاریخ شروع خدمت', 'type' => 'date'],
    ];
    echo '<div class="shared-form-field">';
    foreach ($fields as $key => $field) {
        $value = get_post_meta($post->ID, "_teamfolio_$key", true);
        echo "<div class='shared-form-field'><label for='teamfolio_$key'>{$field['label']}</label><input type='{$field['type']}' id='teamfolio_$key' name='teamfolio_$key' value='" . esc_attr($value) . "' /></div>";
    }
    echo '</div>';
}

add_action('save_post', 'teamfolio_save_personnel_meta');
function teamfolio_save_personnel_meta($post_id) {
    if (!isset($_POST['teamfolio_personnel_meta_box_nonce']) || !wp_verify_nonce($_POST['teamfolio_personnel_meta_box_nonce'], 'teamfolio_personnel_meta_box')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;

    $fields = [
        'position' => 'text',
        'code' => 'text',
        'date' => 'text',
        'email' => 'email',
        'phone' => 'tel',
        'fax' => 'tel',
        'unit' => 'text',
        'resume' => 'url',
        'postal_code' => 'text',
        'start_date' => 'text'
    ];

    foreach ($fields as $key => $type) {
        if (isset($_POST["teamfolio_$key"])) {
            $value = $_POST["teamfolio_$key"];
            if ($type === 'email' && !empty($value) && !is_email($value)) continue;
            if ($type === 'tel' && !empty($value) && !preg_match('/^[0-9+\-\(\) ]+$/', $value)) continue;
            if ($type === 'url' && !empty($value) && !filter_var($value, FILTER_VALIDATE_URL)) continue;
            update_post_meta($post_id, "_teamfolio_$key", sanitize_text_field($value));
        }
    }
}

add_shortcode('teamfolio_chart', 'teamfolio_org_chart_shortcode');
function teamfolio_org_chart_shortcode($atts) {
    $atts = shortcode_atts(['category' => ''], $atts);
    $terms_args = [
        'taxonomy' => 'teamfolio_personnel_category',
        'hide_empty' => false,
        'orderby' => 'term_id',
        'parent' => 0
    ];
    if (!empty($atts['category'])) {
        $terms_args['slug'] = sanitize_text_field($atts['category']);
    }
    $terms = get_terms($terms_args);

    if (empty($terms) || is_wp_error($terms)) {
        return '<p class="shared-error">هیچ دسته‌بندی پرسنلی یافت نشد.</p>';
    }

    $html = '<div class="shared-container teamfolio-chart">';
    $html .= teamfolio_build_tree($terms);
    $html .= '</div>';
    return $html;
}

function teamfolio_build_tree($terms, $level = 0) {
    $html = '<ul class="shared-list teamfolio-tree-level teamfolio-level-' . $level . '">';
    foreach ($terms as $term) {
        $html .= '<li class="shared-list-item teamfolio-tree-item">';
        $html .= '<h2 class="shared-title teamfolio-section-title">' . esc_html($term->name) . '</h2>';

        $args = [
            'post_type' => 'teamfolio_personnel',
            'posts_per_page' => -1,
            'orderby' => 'title',
            'order' => 'ASC',
            'tax_query' => [[
                'taxonomy' => 'teamfolio_personnel_category',
                'field' => 'term_id',
                'terms' => $term->term_id,
                'include_children' => false
            ]]
        ];
        $query = new WP_Query($args);
        if ($query->have_posts()) {
            $html .= '<div class="teamfolio-row">';
            while ($query->have_posts()) {
                $query->the_post();
                $meta = [];
                foreach (['position', 'code', 'email', 'phone', 'unit'] as $key) {
                    $meta[$key] = get_post_meta(get_the_ID(), "_teamfolio_$key", true);
                }
                $thumb = get_the_post_thumbnail(get_the_ID(), 'medium', ['class' => 'shared-avatar teamfolio-thumb']);
                if (!$thumb) {
                    $thumb = '<img src="' . plugin_dir_url(__FILE__) . 'assets/images/default-avatar.png" class="shared-avatar teamfolio-thumb" alt="تصویر پیش‌فرض">';
                }

                $html .= '<a href="' . get_permalink() . '" class="shared-card teamfolio-card">';
                $html .= $thumb;
                $html .= '<h3 class="teamfolio-name">' . get_the_title() . '</h3>';
                $html .= '<p class="teamfolio-position">' . esc_html($meta['position']) . '</p>';
                $html .= '<p class="teamfolio-unit">' . esc_html($meta['unit']) . '</p>';
                $html .= '<p class="teamfolio-email">' . esc_html($meta['email']) . '</p>';
                $html .= '<p class="teamfolio-phone">' . esc_html($meta['phone']) . '</p>';
                $html .= '</a>';
            }
            $html .= '</div>';
            wp_reset_postdata();
        }

        $child_terms = get_terms([
            'taxonomy' => 'teamfolio_personnel_category',
            'hide_empty' => false,
            'parent' => $term->term_id
        ]);
        if (!empty($child_terms) && !is_wp_error($child_terms)) {
            $html .= teamfolio_build_tree($child_terms, $level + 1);
        }

        $html .= '</li>';
    }
    $html .= '</ul>';
    return $html;
}

add_action('init', 'teamfolio_create_org_chart_page');
function teamfolio_create_org_chart_page() {
    if (!current_user_can('manage_options')) return;

    if (get_option('teamfolio_page_created')) return;

    $page = get_page_by_path('org-chart');
    if (!$page) {
        $page_id = wp_insert_post([
            'post_title'   => 'چارت سازمانی',
            'post_content' => '[teamfolio_chart]',
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_name'    => 'org-chart',
            'post_author'  => get_current_user_id() ?: 1
        ]);

        if (!is_wp_error($page_id)) {
            update_option('teamfolio_page_created', true);
        }
    } else {
        update_option('teamfolio_page_created', true);
    }
}

function teamfolio_render_admin_page() {
    if (!is_user_logged_in()) {
        ?>
        <div class="shared-container teamfolio-wrap">
            <div class="shared-error"><p>لطفاً ابتدا وارد شوید.</p></div>
            <a href="<?php echo esc_url(site_url('/teamfolio-login')); ?>" class="shared-btn">ورود</a>
        </div>
        <?php
        return;
    }

    $users = get_users();
    $roles = get_option('teamfolio_roles', []);
    ?>
    <div class="shared-container teamfolio-wrap">
        <h1 class="shared-title">داشبورد تیم‌فولیو</h1>
        <div class="shared-card resume-card">
            <h2 class="shared-title">مدیریت تیم</h2>
            <p><strong>تعداد کاربران:</strong> <?php echo esc_html(count_users()['total_users']); ?></p>
            <p><strong>آخرین ورود شما:</strong> <?php echo esc_html(get_user_meta(get_current_user_id(), 'last_login', true) ?: 'نامشخص'); ?></p>
        </div>

        <div class="teamfolio-section">
            <h3 class="shared-title">اضافه کردن نقش به سامانه</h3>
            <form method="post">
                <?php wp_nonce_field('teamfolio_add_role'); ?>
                <table class="shared-table">
                    <tr>
                        <th><label for="teamfolio_user">انتخاب کاربر</label></th>
                        <td>
                            <select name="teamfolio_user" id="teamfolio_user" required>
                                <option value="">کاربر را انتخاب کنید</option>
                                <?php foreach ($users as $user) : ?>
                                    <option value="<?php echo $user->ID; ?>"><?php echo $user->display_name; ?> (<?php echo $user->user_email; ?>)</option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="teamfolio_role">انتخاب نقش</label></th>
                        <td>
                            <select name="teamfolio_role" id="teamfolio_role">
                                <option value="">نقش را انتخاب کنید</option>
                                <?php foreach ($roles as $role) : ?>
                                    <option value="<?php echo $role; ?>"><?php echo $role; ?></option>
                                <?php endforeach; ?>
                            </select>
                            <button type="button" class="shared-btn" id="teamfolio_add_new_role_btn">اضافه کردن نقش جدید</button>
                        </td>
                    </tr>
                    <tr id="teamfolio_new_role_row" style="display: none;">
                        <th><label for="teamfolio_new_role">نقش جدید</label></th>
                        <td>
                            <input type="text" name="teamfolio_new_role" id="teamfolio_new_role" />
                        </td>
                    </tr>
                    <tr>
                        <th><label for="teamfolio_position">سمت رسمی</label></th>
                        <td>
                            <input type="text" name="teamfolio_position" id="teamfolio_position" readonly />
                        </td>
                    </tr>
                    <tr>
                        <th><label for="teamfolio_personnel_code">کد پرسنلی</label></th>
                        <td>
                            <input type="text" name="teamfolio_personnel_code" id="teamfolio_personnel_code" required />
                        </td>
                    </tr>
                </table>
                <p class="submit">
                    <input type="submit" name="teamfolio_add_role_submit" class="shared-btn" value="ثبت نهایی" />
                </p>
            </form>
        </div>
    </div>
    <?php

    if (isset($_POST['teamfolio_add_role_submit']) && check_admin_referer('teamfolio_add_role')) {
        $user_id = isset($_POST['teamfolio_user']) ? intval($_POST['teamfolio_user']) : 0;
        $role = isset($_POST['teamfolio_role']) ? sanitize_text_field($_POST['teamfolio_role']) : '';
        $new_role = isset($_POST['teamfolio_new_role']) ? sanitize_text_field($_POST['teamfolio_new_role']) : '';
        $personnel_code = isset($_POST['teamfolio_personnel_code']) ? sanitize_text_field($_POST['teamfolio_personnel_code']) : '';

        if ($user_id && $personnel_code) {
            if ($new_role) {
                $role = $new_role;
                $roles = get_option('teamfolio_roles', []);
                if (!in_array($role, $roles)) {
                    $roles[] = $role;
                    update_option('teamfolio_roles', $roles);
                }
            }

            $user = new WP_User($user_id);
            $user->set_role($role);
            $user->add_role('hamkar_collaborator');

            update_user_meta($user_id, 'teamfolio_personnel_code', $personnel_code);

            $user_info = get_userdata($user_id);
            $email = $user_info->user_email;
            $password = wp_generate_password();
            wp_set_password($password, $user_id);

            $site_name = get_bloginfo('name');
            $site_url = get_site_url();
            $subject = 'اضافه شدن به سامانه ' . $site_name;
            $message = "[$user_info->display_name] محترم\n";
            $message .= "با سلام و احترام\n";
            $message .= "بدین وسیله اعلام می‌شود که شما به‌عنوان [$role] به سامانه [$site_name] اضافه شدید\n";
            $message .= "رمز و پسورد شما:\n";
            $message .= "ایمیل: $email\n";
            $message .= "رمز عبور: $password\n\n";
            $message .= "لطفا در حفظ و نگهداری آن کوشا باشید\n";
            $message .= "با سپاس، مدیریت [$site_name]\n";

            $headers = [
                'Content-Type: text/plain; charset=UTF-8',
                'From: ' . $site_name . ' <no-reply@' . parse_url($site_url, PHP_URL_HOST) . '>'
            ];

            $sent = wp_mail($email, $subject, $message, $headers);

            echo '<div class="shared-success"><p>ایمیل با موفقیت ارسال شد. کاربر با موفقیت ثبت شد.</p></div>';
        } else {
            echo '<div class="shared-error"><p>لطفاً همه فیلدها را پر کنید.</p></div>';
        }
    }
}

function teamfolio_render_settings_page() {
    if (!is_user_logged_in()) {
        ?>
        <div class="shared-container teamfolio-wrap">
            <div class="shared-error"><p>لطفاً ابتدا وارد شوید.</p></div>
            <a href="<?php echo esc_url(site_url('/teamfolio-login')); ?>" class="shared-btn">ورود</a>
        </div>
        <?php
        return;
    }

    if (isset($_POST['teamfolio_settings_nonce']) && wp_verify_nonce($_POST['teamfolio_settings_nonce'], 'teamfolio_settings')) {
        $blocked_ips = isset($_POST['blocked_ips']) ? sanitize_text_field($_POST['blocked_ips']) : '';
        update_option('teamfolio_blocked_ips', $blocked_ips);
        echo '<div class="shared-success"><p>تنظیمات ذخیره شد.</p></div>';
    }

    $blocked_ips = get_option('teamfolio_blocked_ips', '');
    ?>
    <div class="shared-container teamfolio-wrap">
        <h1 class="shared-title">تنظیمات تیم‌فولیو</h1>
        <form method="post">
            <?php wp_nonce_field('teamfolio_settings', 'teamfolio_settings_nonce'); ?>
            <div class="shared-form-field">
                <label for="blocked_ips">IPهای بلاک‌شده</label>
                <textarea name="blocked_ips" id="blocked_ips" rows="5"><?php echo esc_textarea($blocked_ips); ?></textarea>
                <p class="description">IPها را با کاما جدا کنید (مثال: 185.1.2.3,91.2.3.4).</p>
            </div>
            <p class="submit">
                <input type="submit" class="shared-btn" value="ذخیره تغییرات" />
            </p>
        </form>
    </div>
    <?php
}

add_action('wp_login', function ($user_login, $user) {
    update_user_meta($user->ID, 'last_login', current_time('mysql'));
}, 10, 2);

add_filter('hamkar_dashboard_data', 'teamfolio_send_dashboard_data');
function teamfolio_send_dashboard_data($dashboard_data) {
    $dashboard_data['pie'] = [
        'labels' => ['تیم A', 'تیم B', 'تیم C'],
        'data' => [40, 35, 25]
    ];
    $dashboard_data['bar'] = [
        'labels' => ['فروردین', 'اردیبهشت', 'خرداد', 'تیر'],
        'data' => [15, 25, 35, 45]
    ];
    $dashboard_data['line'] = [
        'labels' => ['فروردین', 'اردیبهشت', 'خرداد', 'تیر'],
        'data' => [10, 20, 15, 30]
    ];
    return $dashboard_data;
}